from django.contrib import admin

from parse.models import Page, Data

admin.site.register(Page)
admin.site.register(Data)
